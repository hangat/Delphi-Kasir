# Delphi-Kasir
Program Kasir dengan Delphi 7, semudah mungkin, sekecil mungkin, dengan komponen standard bawaan delphi. Sementara masih menggunakan MS Access untuk databasenya, dan komponen akses menggunakan ADO.
